<?php 
    $judul ="Curiculum Vitae";
    $identitas = ["Nama : Ahmad Almer Alana Evan Hamada", "Alamat : Jl.Diponegoro No 90","Email : almeer.evan@gmail.com"];
    $sekolah = ["TK YWKA", "MI Thoriqussalam", "SMPN 3 Sidoarjo",  "SMKN 2 Buduran"];
    $hobies = ["Bermain Game", "Menonton Film","Coding"];
    $skills = ["HTML Expert", "CSS Expert","PHP Newbie","Efotball Expert"];
    echo $judul;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <style>
  .header h1{
    text-align: center;
    font-size: 200px;
  }
 .container-1{
        width: 1200px;
        margin: auto;
        display: flex;
        margin-top: 30px;
        justify-content: center;
    }
    .judul-1 h1{
      text-align: center;
      font-size: 100px;
      margin-bottom: 100px;
    }

    .content img{
        width: 500px;
        display: flex;
        border-radius: 150px;
    }

    .text-1{
        margin: auto;
        text-align: left;
        margin-left:100px;
       
    }

    .text h2{
        margin-bottom: 10px;
        font-size: 50px;
       
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    .container-2{
    display: block;
    height: 800px;
    align-content: center;
    text-align: center;
    margin-top: 200px;
}
.judul{
    font-size: 100px;
    font-weight: bold;
}
.container{
    display: flex;
    justify-content: space-around;
    margin-top: 30px;
    flex-wrap: wrap;
    color: white;
}
.lingkaran img{
    width: 300px;
    height: 300px;
    border-radius: 300px;
    margin:auto;
    
}
.text-2{
    margin-top: 10px;
}
.text-2 h3{
    font-size: 40px;
}
.container-3{
    display: block;
    height: 800px;
    align-content: center;
    text-align: center;
    margin-top: 200px;
}
.judul{
    font-size: 100px;
    font-weight: bold;
}
.wadah{
    display: flex;
    justify-content: space-around;
    margin-top: 30px;
    flex-wrap: wrap;
    color: white;
}
.main img{
    border-radius: 100px;
    width: 500px;
    height: 300px;
    margin:auto;
    
}
.text-3{
    margin-top: 10px;
}
.text-3 h3{
    font-size: 50px;
}
.info{
    margin-top: 20px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-top: 70px;
}

.info-content{
    height: 70px;
    width: 200px;
    display: flex;
    align-items: center;
    margin-top: 30px;
}


.icon img{
    width: 100px;
    height: 100px;
    display: block;
    margin-right: 10px;
}

.info-isi h2{
  font-size: 25px;
}
.judul-2 h1{
  text-align: center;
  font-size: 100px;
  margin-top: 100px;
}
  </style>
</head>
<body>
    <div class="header">
    <h1><?= $judul; ?></h1>
  </div>
              <div class="judul-1">
              <h1>Identitas</h1>
            </div>
          <div class="container-1">
            <div class="content">
                <img src="img/evan.jpg" alt="">
            </div>
            <div class="text-1">
                    <h2><?= $identitas[0]; ?></h2>
                    <h2><?= $identitas[1]; ?></h2>
                    <h2><?= $identitas[2]; ?></h2>
            </div>
        </div>
  <div class="container-2">
				<h1 class="judul">Asal Sekolah</h1>
				<div class="container">
					<div class="text-2">
						<div class="lingkaran">						<img src="img/tk.jpg" alt="" /></div>
						<h3><?=  $sekolah[0]; ?></h3>
					</div>
					<div class="text-2">
						<div class="lingkaran"><img src="img/mi.jpg" alt=""></div>        
						<h3><?=  $sekolah[1]; ?></h3>
					</div>
					<div class="text-2">
						<div class="lingkaran"><img src="img/smp.jpg" alt=""></div>        
						<h3><?=  $sekolah[2]; ?></h3>
					</div>
					<div class="text-2">
						<div class="lingkaran"><img src="img/smk.jpg" alt=""></div>        
						<h3><?=  $sekolah[3]; ?></h3>
					</div>
				</div>
		</div> 
		  <div class="container-3">
				<h1 class="judul">Hobi</h1>
				<div class="wadah">
					<div class="text-3">
						<div class="main"><img src="img/game.jpg" alt="" /></div>
						<h3><?=  $hobies[0]; ?></h3>
					</div>
					<div class="text-3">
						<div class="main"><img src="img/film.jpg" alt=""></div>        
						<h3><?=  $hobies[1]; ?></h3>
					</div>
					<div class="text-3">
						<div class="main"><img src="img/coding.jpg" alt=""></div>        
						<h3><?=  $hobies[2]; ?></h3>
					</div>
				</div>
		</div> 
		<div class="judul-2">
		  <h1>Skill</h1>
		</div>
		        <div class="info">
            <div class="info-content">
              <div class="icon">
              <img src="img/html.png" alt="">
            </div>
            <div class="info-isi">
              <h2><?=  $skills[0]; ?></h2>
            </div>
           </div>
            <div class="info-content">
              <div class="icon">
              <img src="img/css.png" alt="">
            </div>
            <div class="info-isi">
              <h2><?=  $skills[1]; ?></h2>
            </div>
           </div>
            <div class="info-content">
              <div class="icon">
              <img src="img/pho.png" alt="">
            </div>
            <div class="info-isi">
              <h2><?=  $skills[2]; ?></h2>
            </div>
           </div>
            <div class="info-content">
              <div class="icon">
              <img src="img/efb.png" alt="">
            </div>
            <div class="info-isi">
              <h2><?=  $skills[3]; ?></h2>
            </div>
           </div>
        </div>
</body>
</html>